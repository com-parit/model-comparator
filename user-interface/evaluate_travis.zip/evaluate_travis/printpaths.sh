#!/bin/bash

# Check if the number of arguments provided is correct
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <projects_directory>"
    exit 1
fi

# Assign the projects directory path from the argument
projects_directory="$1"

# Check if the provided directory exists
if [ ! -d "$projects_directory" ]; then
    echo "Error: Directory '$projects_directory' not found."
    exit 1
fi

# Function to iterate through directories and gather project details
gather_project_details() {
    local dir="$1"
    # Iterate through each project directory
    for project_dir in "$dir"/*/; do
        if [ -d "$project_dir" ]; then
            # Print the absolute paths of all .emf files in the project directory
			cd "$project_dir/mdre-llm"
			echo "{"
            echo "\"predicted\": \"$(find "." -type f -name "*.emf" -exec readlink -f {} \;)\","
			cd "../model"
            echo "\"original\": \"$(find "." -type f -name "*.emf" -exec readlink -f {} \;)\","
			echo "\"projectName\": \"$(echo "$project_dir" | sed 's/[\/\.]//g')\"" 
			cd "../../"
			echo "},"
        fi
    done
}

# Call the function to gather project details
gather_project_details "$projects_directory"
