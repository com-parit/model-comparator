#!/bin/bash

# Replace with the path to your main directory
MAIN_DIRECTORY="/media/jawad/secondaryStorage/projects/thesis/evaluation/travis/evaluateTravis"

# Iterate over each subdirectory in the main directory
for subdir in "$MAIN_DIRECTORY"/*; do
    if [ -d "$subdir" ]; then
        echo "Processing $subdir..."

        # Navigate to the subdirectory
        cd "$subdir" || continue

        # Remove everything except the 'model' folder
        find . -mindepth 1 -maxdepth 1 ! -name 'model' -exec rm -rf {} +

        # Check if the 'model' folder exists
        if [ -d "model" ]; then
            # Find and copy the .ecore file from the 'model' folder to the subdirectory
            ECORE_FILE=$(find model -name "*.ecore" -type f)
            if [ -n "$ECORE_FILE" ]; then
                cp "$ECORE_FILE" .
                echo "Copied $ECORE_FILE to $subdir"
            else
                echo "No .ecore file found in $subdir/model"
            fi

	    EMF_FILE=$(find model -name "*.emf" -type f)
            if [ -n "$EMF_FILE=" ]; then
                cp "$EMF_FILE" .
                echo "Copied $EMF_FILE to $subdir"
            else
                echo "No .emf file found in $subdir/model"
            fi


            # Delete the 'model' folder
            rm -rf "model"
            echo "Deleted model folder in $subdir"
        else
            echo "'model' folder does not exist in $subdir"
        fi

        # Go back to the main directory
        cd "$MAIN_DIRECTORY" || exit
    fi
done

echo "Script execution completed."

