#!/bin/bash

# Function to create folder "mdre-llm" and copy files into it
copy_files() {
    local dir="$1"
    local dest="$dir/mdre-llm"

    # Create "mdre-llm" folder
    mkdir -p "$dest"

    # Copy files into "mdre-llm" folder
    cp "$dir"/* "$dest"

    # Create "model" folder
    mkdir -p "$dir/model"
}

# Main script
main() {
    local source_folder="$1"

    # Iterate through directories in the source folder
    for dir in "$source_folder"/*; do
        # Check if it's a directory
        if [ -d "$dir" ]; then
            echo "Processing directory: $dir"
            copy_files "$dir"
        fi
    done
}

# Check if the source folder is provided as an argument
if [ $# -ne 1 ]; then
    echo "Usage: $0 <source_folder>"
    exit 1
fi

main "$1"

