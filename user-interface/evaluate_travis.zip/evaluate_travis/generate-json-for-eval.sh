#!/bin/bash

# Check if the number of arguments provided is correct
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <projects_directory>"
    exit 1
fi

# Assign the projects directory path from the argument
projects_directory="$1"

# Check if the provided directory exists
if [ ! -d "$projects_directory" ]; then
    echo "Error: Directory '$projects_directory' not found."
    exit 1
fi

# Define the output JSON file
output_json="output.json"

# Initialize an empty array to store project details
project_details=()

# Function to iterate through directories and gather project details
gather_project_details() {
    local dir="$1"
    for project_dir in "$dir"/*/; do
        if [ -d "$project_dir" ]; then
            project_name=$(basename "$project_dir")
            mdre_llm_file=$(find "$project_dir/mdre-llm" -maxdepth 1 -type f)
            model_file=$(find "$project_dir/model" -maxdepth 1 -type f)
            if [ -n "$mdre_llm_file" ] && [ -n "$model_file" ]; then
                project_details+=("{\"original\": \"$mdre_llm_file\", \"predicted\": \"$model_file\", \"projectName\": \"$project_name\"}")
            fi
        fi
    done
}

# Call the function to gather project details
gather_project_details "$projects_directory"

# Check if any projects were found
if [ ${#project_details[@]} -eq 0 ]; then
    echo "No projects found in '$projects_directory'."
    exit 0
fi

# Convert the array to JSON format
json=$(printf '%s\n' "${project_details[@]}" | jq -s '.')

# Write JSON to file
echo "$json" > "$output_json"

